NIVEAU Samuel 31A


TP2 Partie 2

[![CI](https://github.com/SNIVEAU/BUT3-GitLab-CI-Samuel-Niveau/actions/workflows/ci.yml/badge.svg?branch=main&event=check_run)](https://github.com/SNIVEAU/BUT3-GitLab-CI-Samuel-Niveau/actions/workflows/ci.yml)